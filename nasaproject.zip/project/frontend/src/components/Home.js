import React, { useEffect, useState } from "react";
import moment from 'moment'
import axios from "axios";

//import "./App.css";
const dotenv = require('dotenv');
dotenv.config();

const API_KEY = process.env.REACT_APP_API_KEY;

const baseURL = `https://api.nasa.gov/planetary/apod?api_key=${API_KEY}`;

const Home = () => {
  const [details, setDetails] = useState([]);
  const [loading, setLoading] = useState(false);
  let now = new Date();
  var dateString = moment(now).format('YYYY-MM-DD');
  const [date,setDate] = useState(dateString);

  useEffect(() => {
    fetchData();
  }, []);

  useEffect(() => {
    submitValue();
  }, [date]);

 

  const fetchData = () => {
    axios.get(baseURL)
      .then((response) => {
      setDetails(response.data)
      setLoading(true)
      })
  };



  const submitValue = () => {
    axios.get(`http://localhost:8000/nasaRoute/${date}`)
    .then((response) => {
        console.log(response)
    setDetails(response.data)
    setLoading(true)
    })
    .catch(function (error) {
      if(error.response.status === 404) {
        console.log(error.response.status);      
        axios.get(baseURL+`&date=${date}`).then(function (response) {
            axios.post(`http://localhost:8000/nasaRoute/`,response.data).then(function (response) {
                setDetails(response.data)
                setLoading(true)
         })
        })
      }
     });
    }

    

    if(details.media_type == 'image'){
        return (
            <>
                    <input type="date" onChange={e => setDate(e.target.value)} onClick={submitValue}/>
                    
                    <h1 style={{"text-align":"center"}}>{details.title}</h1>
                    
                    <img src={details.url} className="" alt="photo" />
                    <p><b>Explanation:</b>{details.explanation}</p>
            </>
          );
    } else {
        return (
            <>
                    <input type="date"   onChange={e => setDate(e.target.value)} onClick={submitValue}/>
                    
                    <h1 style={{"text-align":"center"}}>{details.title}</h1>
                    
                    <p>The video link is here :- {details.url}</p>
                    <p><b>Explanation:</b>{details.explanation}</p>
            </>
          );
    }

  
};

export default Home;