const express = require('express');
const path = require('path');

const app = express();
var cors = require('cors')
const dotenv = require('dotenv');
dotenv.config();
const PORT = process.env.PORT;

const client = require('./config/mongo');
if(client != null){
    console.log("database is connected")
}

const nasaRoute = require('./routes/route')


app.use(express.static('public')); 
app.use('/images', express.static('images'));
app.use(express.json());
app.use(cors())

app.use('/',nasaRoute)



app.listen(PORT,function() {
    console.log(`App is running on port ${PORT}`);
});