const dotenv = require('dotenv');
dotenv.config();

var {MongoClient} = require('mongodb');

const uri = process.env.URL;
  

const client = new MongoClient(uri);
try{
    client.connect();
} catch (err) {
    console.log(err);
}



module.exports= client;
