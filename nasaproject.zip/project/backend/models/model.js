const client = require('../config/mongo');
// const saveImage = require('../image')
const download = require('image-downloader')

const fetchByDate = async ( collectionName, date ) => {

    try{

        const result = await client.db("nasaProject").collection(collectionName).findOne({
            date: date
        })
        if(result.url != null){
        let url = result.url;
            let image = url.split( '/' )[6];
            result.url = `http://localhost:8000/images/${image}`;
        }
        
        return result;
    } catch ( err ) {
        console.log(err);
    }
}

const postDetail = async (collectionName, detail) => {
    try{
        if(detail != null) {
            return new Promise(async (resolve, reject) => {
                
                await client.db("nasaProject").collection(collectionName).insertOne(detail).then(result => {
                    if(detail.media_type == "image") {

                        const options = {
                            url: detail.url,
                            dest : 'images'                                         }
                          download.image(options).then(({ filename }) => {
                            console.log('Saved to', filename)  
                            resolve(result)
                          })
                    }
                }).catch(err => {
                    reject(err)
                })
            })
        }
    } catch ( err ) {
        console.log(err);
    }
}

module.exports = {
    fetchByDate,
    postDetail
}