const download = require('image-downloader')

const saveImage = (url) =>{

    const options = {
      url: url,
      dest : 'images/'                // will be saved to /path/to/dest/image.jpg
    }
    
    download.image(options)
      .then(({ filename }) => {
        console.log('Saved to', filename)  // saved to /path/to/dest/image.jpg
      })
      .catch((err) => console.error(err))
}

module.exports = {
    saveImage
}