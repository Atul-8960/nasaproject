const model = require('../models/model')

const getByDate = async(req,res) => {
    const date = req.params.date;
    console.log(date)
    try{
            const data = await model.fetchByDate("nasaDetail", date );

            if(data != null){
                res.json(data);
            } else  {
                return res.status(404).json(null);
            }
            
        } catch (err){
            res.status(404).json({error:"api not worked"})
        }
}

const insertDetail = async (req, res) => {
    const data = req.body;
    try{
        if(data){
            await model.postDetail("nasaDetail", data);
            const newData = await model.fetchByDate("nasaDetail", data.date );

            if(newData != null){
                res.json(newData);
            } else  {
                return res.status(404).json(null);
            }
        } else {
            return res.status(404).json({error : "Please enter the details"})
        }
    } catch (err){
        res.status(404).json({error:err})
    }
}

module.exports ={
    getByDate,
    insertDetail,
}