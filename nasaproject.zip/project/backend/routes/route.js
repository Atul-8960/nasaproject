const express = require('express');

const router = express.Router();

const controller = require('../controllers/controller')

router.get('/nasaRoute',(req, res) => {
    res.json("Hello World")
})

//getByDate

router.get('/nasaRoute/:date',controller.getByDate);

//adding the details

router.post('/nasaRoute',controller.insertDetail)

module.exports = router;
